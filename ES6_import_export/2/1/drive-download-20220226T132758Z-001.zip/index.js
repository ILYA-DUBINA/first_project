import './index.css';
import CookieConsent from'./src/CookieConsent';

new CookieConsent('.cookie-consent');
