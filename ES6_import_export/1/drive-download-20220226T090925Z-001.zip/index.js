import './index.css';
import initApp from './src/app';

initApp();
